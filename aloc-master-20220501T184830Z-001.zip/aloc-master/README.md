# Sistema Básico de Alocação e Controle de Equipamentos

A ideia partiu de uma necessidade no meu setor, para melhorar o controle de equipamentos e melhorar a alocação dos equipamentos.
